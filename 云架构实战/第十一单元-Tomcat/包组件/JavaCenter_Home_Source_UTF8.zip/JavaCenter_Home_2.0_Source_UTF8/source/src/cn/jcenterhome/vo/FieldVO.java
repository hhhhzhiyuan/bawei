package cn.jcenterhome.vo;


public class FieldVO {
	private String name;
	private boolean isInt;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isInt() {
		return isInt;
	}

	public void setInt(boolean isInt) {
		this.isInt = isInt;
	}
}