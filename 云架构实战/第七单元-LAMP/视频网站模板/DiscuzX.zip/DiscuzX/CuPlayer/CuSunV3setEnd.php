﻿<?php
require '../source/class/class_core.php';
$discuz = & discuz_core::instance();
$discuz->init(); //以上是调用discuz公共执行类等核心代码

$groupid  =$_G['groupid'];  //用户等级
?><CuPlayer>
 <Player_Set 
		JcScpBufferTime = "3"
 		JcScpVolume = "75"
		JcScpCode = "utf8"
 		JcScpImgDisplay = "no"
		JcScpAutoHideControl="yes"
		JcScpControlHideTime="0.5"
		JcScpControlHeight="40"	
		JcScpShowList= "yes"
		JcScpAutoRepeat = "no"
		JcScpAutoPlay = "yes"
		JcScpsetMode = "1"
		JcScpAFrontCanClose = "no"
		JcScpShowRightmenu = "yes"
		JcScpShareMode = "JcScpVideoPath"
		JcScpLoadbarMode = "0"
        JcScpLiveMode  = "0"
	/>

      <Logo_Set
 		JcScpLogoDisplay = "no"
 		JcScpLogoPath = "images/logo.png"
 		JcScpLogoPosition = "top-left"
		JcScpLogoWidth = "265"
 		JcScpLogoHeight = "75"
 		JcScpLogoAlpha = "0.2"
	/>

      <Flashvars_Set 
	  
       JcScpServer  =""
       JcScpVideoPath = ""

		JcScpVideoPathHD = ""
		JcScpImg ="images/a820x465_01.jpg" 
        JcScpTitle  = ""
		JcScpStarTime = "0" 
		  <?  if (empty($_G['uid'])) {?>
        JcScpEndTime ="10"

        <? }  else { ?>
        JcScpEndTime ="0"
        <? }?>
 
		
		JcScpCuePointInfo = "提示点信息1|提示点2|提示点3"
		JcScpCuePointTime = "50|80|120"
		
		ShowJcScpAFront = "no"
		JcScpCountDowns = "8"
		JcScpCountDownsPosition = "top-right"
		JcScpAFrontW = "730"
		JcScpAFrontH = "454"
		JcScpAFrontPath = "images/a730x454_01.jpg|images/a730x454_02.jpg|images/a730x454_03.jpg|images/a730x454_04.jpg"
		JcScpAFrontLink = "http://v3.cuplayer.com/link/L011.html|http://v3.cuplayer.com/link/L012.html|http://v3.cuplayer.com/link/L013.html|http://v3.cuplayer.com/link/L014.html"
		 
		ShowJcScpAVideo= "yes"
		JcScpAVideoServer= ""	
		JcScpAVideoPath= "http://promotion.geely.com/xindihao/media/video1.mp4|http://promotion.geely.com/xindihao/media/video2.mp4|http://promotion.geely.com/xindihao/media/video3.mp4"	
		JcScpAVideoLink= "http://v3.cuplayer.com/link/L021.html|http://v3.cuplayer.com/link/L022.html|http://v3.cuplayer.com/link/L023.html"
		
		ShowJcScpAPause = "yes"
		JcScpAPausePath = "images/a300x250_01.swf|images/a300x250_02.swf|images/a300x250_01.jpg|images/a300x250_02.jpg"
		JcScpAPausePaths = "images/startpic.jpg"
		JcScpAPauseW = "300"
		JcScpAPauseH = "250"
		JcScpAPauseLink= "http://v3.cuplayer.com/link/L031.html|http://v3.cuplayer.com/link/L032.html|http://v3.cuplayer.com/link/L033.html|http://v3.cuplayer.com/link/L034.html"
		
		ShowJcScpACorner = "yes"
		JcScpACornerPath= "images/a370x250.swf|images/a370x250.swf|images/a370x250.swf"
		JcScpACornerW = "90"
		JcScpACornerH = "50"
		JcScpACornerPosition = "top-right"
		JcScpACornerLink = "http://v3.cuplayer.com/link/L041.html|http://v3.cuplayer.com/link/L042.html|http://v3.cuplayer.com/link/L043.html"
 
		ShowJcScpAEnd = "yes"
		JcScpAEndPath = "images/a400x300.swf|images/a400x300.swf"
		JcScpAEndW = "400"
		JcScpAEndH = "300"
		JcScpAEndLink= "http://v3.cuplayer.com/link/L051.html|http://v3.cuplayer.com/link/L051.html"

		ShowJcScpAMoveText = "yes"
		
	 />

	 <SkinColor_Set
 		JcScpBackcolor = "0x000000"
        JcScpBackcolortop = "0x353535"
        JcScpLightcolor = "0xcfcfcf"
        
        JcScpFontcolor = "0xffffff"
        JcScptimebg = "0x393939"
        
        JcScpLoadbar = "0x00a0e9"
        JcScpLoaded = "0x4d4b4b"
        JcScpLoadbg = "0x000000"
        JcScpPlayBtn = "0x2d2d2d"
		
        JcScpBar = "0xffffff" 
	 />

<news loop="true" textWidth="500" speed="30">
	<li links="http://v3.cuplayer.com/link/L012.html">1.市场疲弱鼓励政策频出 自住购房置业的最佳时机</li>
	<li links="http://v3.cuplayer.com/link/L012.html">2.通胀预期回升对企业估值影响复杂</li>
	<li links="http://v3.cuplayer.com/link/L012.html">3.2016年新金融创新创业发展论坛25号将在深圳举办</li>
	<li links="http://v3.cuplayer.com/link/L012.html">4.天津滨海新区将建跨境电商产业园 打造发展高地</li>
	<li links="http://v3.cuplayer.com/link/L012.html">5.利用欧美政策分化押注美元升值是否仍可行</li>
</news>


  <thumbnail> 
		<filename>pic/pic01.jpg</filename> 
		<title>1中国品牌手机厂商崛起三星业绩下滑</title> 
		<url>http://v3.cuplayer.com/link/L011.html</url> 
		<target>_blank</target> 
	</thumbnail> 
	<thumbnail> 
		<filename>pic/pic02.jpg</filename> 
		<title>2中国联通双4G领先计划高端峰会</title> 
		<url>http://v3.cuplayer.com/link/L012.html</url> 
		<target>_blank</target> 
	</thumbnail> 
	<thumbnail> 
		<filename>pic/pic03.jpg</filename> 
		<title>3电动汽车配套设施称烫手山芋</title> 
		<url>http://v3.cuplayer.com/link/L013.html</url> 
		<target>_blank</target> 
	</thumbnail> 
	<thumbnail> 
		<filename>pic/pic04.jpg</filename> 
		<title>4腾讯开放平台将连接智能硬件</title> 
		<url>http://v3.cuplayer.com/link/L014.html</url> 
		<target>_blank</target> 
	</thumbnail> 
	 <thumbnail> 
		<filename>pic/pic05.jpg</filename> 
		<title>5微软再裁员3000大裁员计划完成</title> 
		<url>http://v3.cuplayer.com/link/L011.html</url> 
		<target>_blank</target> 
	</thumbnail> 
	<thumbnail> 
		<filename>pic/pic06.jpg</filename> 
		<title>6阿里巴巴双十一商标杀伤力</title> 
		<url>http://v3.cuplayer.com/link/L012.html</url> 
		<target>_blank</target> 
	</thumbnail> 
 	<thumbnail> 
		<filename>pic/pic03.jpg</filename> 
		<title>7电动汽车配套设施称烫手山芋</title> 
		<url>http://v3.cuplayer.com/link/L013.html</url> 
		<target>_blank</target> 
	</thumbnail> 
	<thumbnail> 
		<filename>pic/pic04.jpg</filename> 
		<title>8腾讯开放平台将连接智能硬件</title> 
		<url>http://v3.cuplayer.com/link/L014.html</url> 
		<target>_blank</target> 
	</thumbnail> 
	 <thumbnail> 
		<filename>pic/pic05.jpg</filename> 
		<title>9微软再裁员3000大裁员计划完成</title> 
		<url>http://v3.cuplayer.com/link/L011.html</url> 
		<target>_blank</target> 
	</thumbnail> 
	<thumbnail> 
		<filename>pic/pic06.jpg</filename> 
		<title>10阿里巴巴双十一商标杀伤力</title> 
		<url>http://v3.cuplayer.com/link/L012.html</url> 
		<target>_blank</target> 
	</thumbnail> 
	<thumbnail> 
		<filename>pic/pic06.jpg</filename> 
		<title>111阿111巴巴双十一商标杀伤力</title> 
		<url>http://v3.cuplayer.com/link/L013.html</url> 
		<target>_blank</target> 
	</thumbnail> 
  
</CuPlayer>